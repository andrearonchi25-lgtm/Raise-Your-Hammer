RAISE YOUR HAMMER — INSTALLAZIONE DA TELEFONO

Questa è la versione PWA installabile direttamente da Android, senza Android Studio.

1. Pubblica questa cartella su un hosting HTTPS (per esempio GitHub Pages, Netlify o Vercel).
2. Apri l'indirizzo HTTPS dal telefono.
3. Nel menu del browser scegli "Installa app" / "Aggiungi alla schermata Home".
4. Raise Your Hammer apparirà come una vera app sul telefono.

La PWA include:
- modalità standalone
- icona
- splash/theme del telefono
- cache offline
- salvataggio locale della app
- versione ULTIMATE dell'asta

Nota: per l'installazione PWA il sito deve essere servito in HTTPS. Il file locale index.html aperto direttamente dal file manager non attiva tutte le funzioni PWA.
